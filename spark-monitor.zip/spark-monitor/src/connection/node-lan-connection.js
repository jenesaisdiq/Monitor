var NodeLANConnection = (function() {
  return {
    transportName: 'NodeLAN',
    receivers: {
      pins: [],
      variables: [],
      status: []
    },
    targetIP: undefined,
    net: undefined,
    tcpClient: undefined,
    canary: undefined,
    lastDataTimestamp: 0,
    connectionLock: false,

    initialize: function() {
      if (!chromeAvailable() && requireAvailable()) {
        this.net = require('net');
      }
    },

    connect: function() {
      console.log("NodeLAN connect called");

      // this isn't a Node environment
      if (chromeAvailable() || !requireAvailable()) {
        return Promise.resolve(false);
      }

      // periodically checks on the connection, starts reconnects
      this.makeConnectionCanary();

      // don't try to connect if we're already in progress
      if (!this.connectionLock) {
        // gives a few seconds when no reconnect attempts
        // will tear down this socket
        this.takeConnectionLock();

        if (exists(this.tcpClient)) {
          this.tcpClient.destroy();
          this.tcpClient = undefined;
        }

        this.tcpClient = new this.net.Socket();
        this.tcpClient.on('data', this.onSocketDataReceived.bind(this));
        this.tcpClient.on('close', this.onSocketDisconnected.bind(this));
        this.tcpClient.on('error', function(e) {console.error(e)});
        this.tcpClient.on('end', this.onSocketDisconnected.bind(this));
        this.tcpClient.on('connect', this.onSocketConnected.bind(this));

        Promise.resolve(spark.getVariable(ConnectionManager.monitor.state.activeDeviceId, 'ip'))
        .timeout(1000, "Spark variable fetch (ip) timed out.")
        .then((function(sparkResponse) {
          console.log("IP recovered in NodeLAN", sparkResponse)
          this.targetIP = sparkResponse.result;
          this.tcpClient.connect(7073, this.targetIP);
        }).bind(this))
        .catch((function(e) {
          console.error(e);
          this.connectionLock = false;
        }).bind(this));
      }
    },

    onSocketConnected: function() {
      this.connectionLock = false;
      console.log('NodeLAN connecting');
      this.lastDataTimestamp = _.now();
      this.emitEvent('status', 'connected');
    },

    onSocketDataReceived: function(info) {
      this.lastDataTimestamp = _.now();
      try {
        var s = info.toString();
        _.forEach(s.split('~'), function(subs) {
          if (subs.trim().length > 0) {
            var data = JSON.parse(subs);
            if (data.type === 'pins') {
              this.onNewPins(data.pins.analog.concat(data.pins.digital));
            } else if (data.type === 'vars') {
              this.onNewVariables(data.vars);
            }
          }
        }, this);
      } catch(e) {
        console.error(e);
        var s = ab2str(info.data);
        console.error("Failed processing data from LAN:", s);
      }
    },

    onSocketDisconnected: function() {
      this.connectionLock = false;
      console.log("Socket disconnected");
      if (exists(this.canary)) {
        // clearInterval(this.canary);
        // this.canary = undefined;
      }

      console.log("Lost LAN connection!");
      this.emitEvent('status', 'disconnected');

      this.reconnect();
    },

    takeConnectionLock: function() {
      this.connectionLock = true;
      setTimeout(function() {
        this.connectionLock = false;
      }.bind(this), 5000);
    },

    reconnect: function() {
      console.log('NodeLAN reconnecting');
      this.connect();
    },

    resetConnection: function() {
      console.log('NodeLAN resetting');
      if (exists(this.tcpClient)) {
        this.tcpClient.close();
        this.tcpClient.destroy();
        this.tcpClient = undefined;
        this.connectionLock = false;
      }
      return Promise.resolve(true);
    },

    onNewPins: function(pinArray) {
      this.emitEvent('pins', pinArray);
    },

    onNewVariables: function(variablesObject) {
      this.emitEvent('variables', variablesObject);
    },

    emitEvent: function(feed, data) {
      _.each(this.receivers[feed], function(receiverObject) {
        receiverObject.callback({
          source: this.transportName,
          feed: feed,
          data: data});
      }, this);
    },

    // API documented in this method of connection-manager.js
    registerDataReceiver: function(receiverObject) {
      var id = _.uniqueId();

      for (feed in this.receivers) {
        if (receiverObject[feed] !== undefined) {
          this.receivers[feed].push({id: id, callback: receiverObject[feed]});
        }
      }

      return id;
    },

    unregisterDataReceiver: function(receiverId) {
      for (feed in this.receivers) {
        _.remove(this.receivers[feed], function(receiverObject) {
          return receiverObject.id === receiverId;
        });
      }
    },

    makeConnectionCanary: function() {
      if (exists(this.canary)) {
        clearInterval(this.canary);
      }
      this.canary = setInterval(function() {
        console.log("Canary checking...");
        this.connected().bind(this)
        .then(function(connected) {
          if (!connected) {
            this.reconnect();
          }
        });
      }.bind(this), 5000);
      // else {
      //   console.log("Canary already exists")
      // }

    },

    connected: function() {
      if (chromeAvailable() || !requireAvailable()) {
        return Promise.resolve(false);
      } else if (!exists(this.tcpClient)) {
        console.log("LAN status: disconnected: no socket");
        return Promise.resolve(false);
      } else if (_.now() - this.lastDataTimestamp > 5000) {
        console.log("LAN status: disconnected: no recent data");
        return Promise.resolve(false);
      } else {
        return Promise.resolve(this.tcpClient.readable);
      }
    }
  }







})();

NodeLANConnection.initialize();





