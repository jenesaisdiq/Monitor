var LANConnection = (function() {
  return {
    transportName: 'LAN',
    receivers: {
      pins: [],
      variables: [],
      status: []
    },
    targetIP: undefined,
    socketId: undefined,
    canary: undefined,
    reconnectId: undefined,
    lastDataTimestamp: 0,

    connect: function() {
      console.log("LAN connect called");
      if (exists(this.reconnectId)) {
        clearTimeout(this.reconnectId);
      }
      // e.g. this is Atom
      if (!chromeAvailable()) {
        return;
      }

      chrome.sockets.tcp.onReceive.addListener(this.onSocketDataReceived.bind(this));
      chrome.sockets.tcp.onReceiveError.addListener(this.onSocketDisconnected.bind(this));


      Promise.resolve(spark.getVariable(ConnectionManager.monitor.state.activeDeviceId, 'ip'))
      .timeout(2000, "Spark variable fetch (ip) timed out.")
      .then(function(sparkResponse) {
        this.targetIP = sparkResponse.result;
        chrome.sockets.tcp.create({}, this.onSocketCreated.bind(this));
      }.bind(this))
      .catch(function(e) {
        console.error(e);
      });

      // if it works, this will be cleared on success.
      // otherwise it will initiate a reconnect after the specified delay
      clearTimeout(this.reconnectId);
      this.reconnectId = setTimeout(this.reconnect.bind(this), 5000);
    },

    onSocketCreated: function(createInfo) {
      console.log("Socket created.");
      if (!exists(this.socketId)) {
        this.socketId = createInfo.socketId;
        chrome.sockets.tcp.connect(createInfo.socketId, this.targetIP, 7073,
          this.onSocketConnected.bind(this));
      } else {
        console.log("We already own a socket. Closing this one.");
        chrome.sockets.tcp.disconnect(createInfo.socketId);
      }

    },

    onSocketConnected: function(result) {
      console.log("result of connecting: " + result);
      var success = (result === 0);

      if (success) {
        clearTimeout(this.reconnectId);
        this.lastDataTimestamp = _.now();
        this.emitEvent('status', 'connected');
        this.makeConnectionCanary();
      }
    },

    onSocketDataReceived: function(info) {
      // slowlog(info);
      if (info.socketId === this.socketId) {
        // slowlog("info socketId", info.socketId, "this socketId", this.socketId);
        this.lastDataTimestamp = _.now();
        try {
          var s = ab2str(info.data);
          // slowlog(s);
          _.forEach(s.split('~'), function(subs) {
            if (subs.trim().length > 0) {
              var data = JSON.parse(subs);
              if (data.type === 'pins') {
                this.onNewPins(data.pins.analog.concat(data.pins.digital));
              } else if (data.type === 'vars') {
                this.onNewVariables(data.vars);
              }
            }
          }, this);
        } catch(e) {
          console.error(e);
          var s = ab2str(info.data);
          console.error("Failed processing data from LAN:", s);
        }
      }
    },

    onSocketDisconnected: function() {
      console.log("Socket disconnected");
      if (exists(this.canary)) {
        clearInterval(this.canary);
        this.canary = undefined;
      }

      this.socketId = undefined;
      console.log("Lost LAN connection!");
      this.emitEvent('status', 'disconnected');

      this.reconnect();
    },

    resetConnection: function() {
      console.log("LAN resetting");
      if (exists(this.canary)) {
        clearInterval(this.canary);
        this.canary = undefined;
      }
      if (exists(this.socketId)) {
        console.log("LAN resetting, has open socket");
        var oldSocket = this.socketId;
        this.socketId = undefined;
        this.lastDataTimestamp = 0;
        return new Promise(function(resolve, reject) {
          chrome.sockets.tcp.disconnect(oldSocket, function() {
            console.log("Socket closed for reset.");
            resolve(true);
          }.bind(this));
        });
      } else {
        console.log("LAN resetting, has no socket");
        this.socketId = undefined;
        return Promise.resolve(true);
      }
      // var oldSocket = this.socketId;
      // this.socketId = undefined;

      // return new Promise(function(resolve, reject) {
      //   if (exists(this.socketId)) {
      //     console.log("LAN resetting, has open socket");
      //     chrome.sockets.tcp.disconnect(this.socketId, (function() {
      //       console.log("Socket closed for reset.");
      //       resolve(true);
      //     }.bind(this)));
      //     this.lastDataTimestamp = 0;
      //   } else {

      //   }
      // });
    },

    reconnect: function() {
      clearTimeout(this.reconnectId);
      if (exists(this.socketId)) {
        chrome.sockets.tcp.disconnect(this.socketId, (function() {
          console.log("Socket closed for reconnect.");
          this.socketId = undefined;
          this.connect();
        }.bind(this)));
      } else {
        console.log("No socket to close, reconnecting.");
        this.connect();
      }
    },

    onNewPins: function(pinArray) {
      this.emitEvent('pins', pinArray);
    },

    onNewVariables: function(variableObject) {
      this.emitEvent('variables', variableObject);
    },

    emitEvent: function(feed, data) {
      _.each(this.receivers[feed], function(receiverObject) {
        receiverObject.callback({
          source: this.transportName,
          feed: feed,
          data: data});
      }, this);
    },

    // API documented in this method of connection-manager.js
    registerDataReceiver: function(receiverObject) {
      var id = _.uniqueId();

      for (var feed in this.receivers) {
        if (receiverObject[feed] !== undefined) {
          this.receivers[feed].push({id: id, callback: receiverObject[feed]});
        }
      }

      return id;
    },

    unregisterDataReceiver: function(receiverId) {
      for (var feed in this.receivers) {
        _.remove(this.receivers[feed], function(receiverObject) {
          return receiverObject.id === receiverId;
        });
      }
    },

    makeConnectionCanary: function() {
      this.canary = setInterval(function() {
        this.connected().bind(this)
        .then(function(connected) {
          if (!connected) {
            this.onSocketDisconnected();
          } else {
            // chrome.sockets.tcp.send(this.socketId, str2ab('heartbeat'), function(){});
          }
        });
      }.bind(this), 5000);
    },

    connected: function() {
      if (!chromeAvailable()) {
        return Promise.resolve(false);
      } else if (!exists(this.socketId)) {
        console.log("LAN disconnected: no socket");
        return Promise.resolve(false);
      } else if (_.now() - this.lastDataTimestamp > 8000) {
        console.log("LAN disconnected: no recent data");
        return Promise.resolve(false);
      } else {
        return new Promise(function(resolve, reject) {
          chrome.sockets.tcp.getInfo(this.socketId, function(info) {resolve(info.connected);});
        }.bind(this));
      }
    }
  };







})();

var slowlog = _.throttle(function() {
    console.log(arguments);
}, 100);





