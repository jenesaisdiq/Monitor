var SSEConnection = (function() {
  return {
    transportName: 'SSE',
    receivers: {
      pins: [],
      variables: [],
      status: []
    },
    deviceConnected: true,

    connect: function() {
      console.log("SSE connect called");
      if (exists(ConnectionManager.monitor.state.activeDeviceId)) {
        spark.getEventStream(false, ConnectionManager.monitor.state.activeDeviceId, this.onNewData.bind(this));
        this.emitEvent('status', 'connected');
      }
    },

    onNewData: function(message) {
      if (message.coreid === ConnectionManager.monitor.state.activeDeviceId) {
        console.log(message);
        if (message.name === "pins") {
          var pins = message.data.split(',');
          this.onNewPins(pins);
        } else if (message.name === "vars") {
          var varsObject = {};

          _.forEach(message.data.split(','), function(subs) {
            if (subs.indexOf(":") > -1) {
              var components = subs.split(':');
              varsObject[components[0]] = components[1];
            }
          });

          this.onNewVariables(varsObject);
        } else if (message.name === "spark/status") {
          if (message.data === "offline") {
            this.deviceConnected = false;
            this.emitEvent('status', 'disconnected');
          } else if (message.data === "online") {
            this.deviceConnected = true;
            this.emitEvent('status', 'connected');
          }
        }
      } else {
        // console.log("SSE got message from other core");
      }
    },

    resetConnection: function() {
      console.log("SSE resetting");
      return Promise.resolve(true);
    },

    onNewPins: function(pinArray) {
      this.emitEvent('pins', pinArray);
    },

    onNewVariables: function(variablesObject) {
      this.emitEvent('variables', variablesObject);
    },

    emitEvent: function(feed, data) {
      _.each(this.receivers[feed], function(receiverObject) {
        receiverObject.callback({
          source: this.transportName,
          feed: feed,
          data: data});
      }, this);
    },

    // API documented in this method of connection-manager.js
    registerDataReceiver: function(receiverObject) {
      var id = _.uniqueId();

      for (var feed in this.receivers) {
        if (receiverObject[feed] !== undefined) {
          this.receivers[feed].push({id: id, callback: receiverObject[feed]});
        }
      }

      return id;
    },

    unregisterDataReceiver: function(receiverId) {
      for (var feed in this.receivers) {
        _.remove(this.receivers[feed], function(receiverObject) {
          return receiverObject.id === receiverId;
        });
      }
    },

    connected: function() {
      return Promise.resolve(spark.ready() && this.deviceConnected);
    }
  };
})();










