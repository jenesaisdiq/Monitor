// This connection is no longer in use.
// It hammers the API for exposed variables.
var APIConnection = (function() {
  return {
    transportName: 'API',
    receivers: {
      pins: [],
      variables: [],
      status: []
    },
    pinsTimeout: undefined,
    variablesTimeout: undefined,

    connect: function() {
      // this.emitEvent('status', 'connected');
    },

    getPins: function() {
      clearTimeout(this.pinsTimeout);
      spark.getVariable(ConnectionManager.monitor.state.activeDeviceId, 'pinstate')
      .then(function(responseObject) {
          this.onNewPins(JSON.parse(responseObject.result));
      }.bind(this))
      .catch(function(e) {
        console.error(e);
      })
      .then(function() {
        this.pinsTimeout = setTimeout(this.getPins.bind(this), 1000);
      }.bind(this));
    },

    getVariables: function() {
      clearTimeout(this.variablesTimeout);
      var deviceId = ConnectionManager.monitor.state.activeDeviceId;
      Promise.resolve(spark.getAttributes(deviceId))
      .bind(this)
      .get('variables')
      .then(Object.keys)
      .map(function(variableName) {
        return spark.getVariable(deviceId, variableName);
      })
      .reduce(function(variablesObject, responseObject) {
        variablesObject[responseObject.name] = responseObject.result;
        return variablesObject;
      }, {})
      .then(this.onNewVariables)
      .catch(function(e) {
        console.error(e);
      })
      .then(function() {
        this.variablesTimeout = setTimeout(this.getVariables.bind(this), 2000);
      }.bind(this));
    },

    onNewPins: function(pinArray) {
      this.emitEvent('pins', pinArray);
    },

    onNewVariables: function(variableObject) {
      this.emitEvent('variables', variableObject);
    },

    emitEvent: function(feed, data) {
      _.each(this.receivers[feed], function(receiverObject) {
        receiverObject.callback({
          source: this.transportName,
          feed: feed,
          data: data});
      }, this);
    },

    /*
      Given an object of the form
      {
        pins: function({
          source: <"LAN"|"API">,
          feed: 'pins'
          data: pinArray
        }),
        variables: function({
          source: <"LAN"|"API">,
          feed: 'variables'
          data: variableObject
        })
      }
      this will result in the appropriate callback being called whenever updates
      are available for either pins or variables.

      Returns an id which can be used to unregister a receiver.
    */
    registerDataReceiver: function(receiverObject) {
      var id = _.uniqueId();

      for (var feed in this.receivers) {
        if (receiverObject[feed] !== undefined) {
          this.receivers[feed].push({id: id, callback: receiverObject[feed]});
        }
      }

      this.getPins();
      this.getVariables();
      return id;
    },

    unregisterDataReceiver: function(receiverId) {
      for (var feed in this.receivers) {
        _.remove(this.receivers[feed], function(receiverObject) {
          return receiverObject.id === receiverId;
        });
      }
      if (this.receivers.pins.length === 0) {
        clearTimeout(this.pinsTimeout);
      }
      if (this.receivers.variables.length === 0) {
        clearTimeout(this.variablesTimeout);
      }
    },

    connected: function() {
      // return Promise.resolve(false);
      var connectedDevices = _.filter(spark.devices, function(device) {
        return Promise.resolve(device.connected);
      });
      var activeDevice = _.find(connectedDevices, function(device) {
        return Promise.resolve(device.id === monitor.state.activeDeviceId);
      });
      return Promise.resolve(exists(activeDevice));
      // return Promise.resolve(spark.ready());
    }
  };
})();
