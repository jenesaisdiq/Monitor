// This is not in use.
// It was build to implement job queuing and rate limiting / exponential backoff
// for the APIConnection to prevent crashing the Core or the servers.
var RateLimiter = (function() {
  return {
    maxOutstandingRequests: 8,
    outstandingRequests: 0,
    queuedRequests: [],

    autoDecrementInterval: setInterval((function() {
      if (this.outstandingRequests > 0) {
        this.outstandingRequests--;
      }
    }).bind(this), 20 * 1000),

    delay: function() {
      var backoff = BASE_SAMPLE_RATE * Math.pow(1.5, Math.max(0, this.outstandingRequests - 5));
      return Math.max(backoff, MIN_SAMPLE_RATE);
    },

    // takes a function which returns a JQuery request
    registerDelayedRequest: function(request) {
      request.id = _.uniqueId();
      this.queuedRequests.push(request);
      return request.id;
    },

    unregisterDelayedRequest: function(requestId) {
      _.remove(this.queuedRequests, function(req) {
        return req.id == requestId;
      });
    },

    popNextRequest: function() {
      var deferredRequests = [];
      while (this.queuedRequests.length > 0) {
        var request = this.queuedRequests.shift();

        // request has been called too recently
        if (request.recurring && _.now() - request.lastUpdate < request.maxUpdateRate) {
          deferredRequests.push(request);
        } else {
          this.queuedRequests = this.queuedRequests.concat(deferredRequests);
          return request;
        }
      }
      this.queuedRequests = this.queuedRequests.concat(deferredRequests);
      return null;
    },

    requestLoop: function() {
      var request = this.popNextRequest();

      if (request != null) {
        if (this.outstandingRequests < this.maxOutstandingRequests) {
          // add a hook to the JQuery request to decrement the counter
          var httpRequest = request.callback();
          if (httpRequest !== null && typeof httpRequest !== 'undefined') {
            this.outstandingRequests++;
            httpRequest.always( (function() {this.outstandingRequests--}).bind(this) );
          }
        }

        if (request.recurring) {
          request.lastUpdate = _.now();
          this.queuedRequests.push(request);
        }
        console.log("Current delay: " + this.delay());
      }

      setTimeout(this.requestLoop.bind(this), this.delay());
    }
  }
})();

RateLimiter.requestLoop();
