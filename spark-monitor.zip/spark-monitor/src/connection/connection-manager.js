ConnectionManager = (function() {
  return {
    activeConnection: null,
    // these should be listed in order of precedence
    // (earlier transports will be used preferentially)
    transports: [LANConnection, NodeLANConnection, SSEConnection],
    transportDataReceiverIds: null,
    receivers: {
      pins: [],
      variables: []
    },
    monitor: undefined,
    triggers: ['boot',
               'retrievedAPIToken',
               'awaitingLogin',
               'loggedIn',
               'awaitDevices',
               'deviceConnected',
               'connected',
               'disconnected',
               'changeDevice'],

    dispatch: function(trigger, data) {
      if (!_.contains(this.triggers, trigger)) {
        throw "Invalid trigger! No such trigger `" + trigger + "`.";
      } else {
        console.log(trigger, "dispatched!");

        switch (trigger) {
          // these are part of the setup process and should only happen once
          case 'boot':
            this.fetchStoredToken();
            break;
          case 'retrievedAPIToken':
            var token = data;
            this.loginWithToken(token);
            break;
          case 'awaitingLogin':
            this.monitor.setState({status: 'awaitingLogin'});
            break;
          case 'loggedIn':
            // this.loadDevicesIntoMonitor();
            this.monitor.setState({status: 'loggedIn'});
            this.dispatch('awaitDevices');
            console.log("setting loggedIn");
            setInterval(this.loadDevicesIntoMonitor.bind(this), 5000);
            break;

          // these may happen multiple times as connections are made and lost
          case 'awaitDevices':
            this.awaitConnectedDevice();
            this.loadDevicesIntoMonitor();
            console.log("setting awaitDevices");
            this.monitor.setState({status: 'awaitDevices'});
            break;
          case 'deviceConnected':
            this.loadDevicesIntoMonitor();
            var connectedDevices = data;
            this.chooseMonitorActiveDevice(connectedDevices).then(function() {
              this.connect();
            });
            this.monitor.setState({status: 'deviceConnected'});
            break;
          case 'connected':
            var transportName = data;
            this.getConnectionStatuses().bind(this)
            .then(this.chooseActiveConnection);
            this.monitor.setState({status: 'connected'});
            break;
          case 'disconnected':
            var transportName = data;
            if (transportName === this.activeConnection.transportName) {
              this.getConnectionStatuses().bind(this)
              .then(this.chooseActiveConnection)
              .then(function(connected) {
                if (!connected) {
                  this.monitor.forceUpdate();
                  this.loadDevicesIntoMonitor();
                  this.dispatch('awaitDevices');
                }
              });
            }
            break;

          case 'changeDevice':
            this.resetConnection().bind(this)
            .then(function() {
              this.connect();
            });
            break;
        }
      }

      this.monitor.forceUpdate()
    },

    initialize: function(monitor) {
      this.monitor = monitor;
      this.transportDataReceiverIds = _.zipObject(
        _.map(this.transports,
          function(transport){return transport.transportName},
          this),
        _.times(this.transports.length,
          function(){return undefined}))
      this.dispatch('boot');
    },

    fetchStoredToken: function() {
      LocalStorage.get(LocalStorage.SPARK_ACCESS_TOKEN_KEY).bind(this)
        .then(function(token) {
          if (!exists(token)) {
            this.dispatch('awaitingLogin');
          } else {
            this.dispatch('retrievedAPIToken', token);
          }
        })
        .catch(function(e) {
          console.error(e);
        });
    },

    loginWithToken: function(token) {
      spark.accessToken = token;
      this.dispatch('loggedIn');

      // double-check that the token is still valid
      Promise.resolve(spark.login({accessToken: token})).bind(this)
      .then(function(result) {
        if (exists(result) && exists(result.accessToken)) {
          console.log('Spark token confirmed.')
        } else {
          this.dispatch('awaitingLogin');
        }
      });

      return Promise.resolve(true);

    },

    loginWithPassword: function(username, password) {
      return Promise.resolve(spark.login({username: username, password: password})).bind(this)
      .then(function(result) {
        if (exists(result) && exists(result.access_token)) {
          this.storeToken(result.access_token);
          this.dispatch('loggedIn');
          return Promise.resolve(true);
        } else {
          this.dispatch('awaitingLogin');
          return Promise.resolve(false);
        }
      })
    },


    loadDevicesIntoMonitor: function() {
      return Promise.resolve(spark.listDevices()).bind(this)
        .then(function(devices) {
          this.monitor.setState({devices: devices});
        });
    },

    awaitConnectedDevice: function() {
      Promise.resolve(spark.listDevices()).bind(this)
      .then(function(devices) {
        var connectedDevices = _.filter(devices, function(device) {
          return device.connected;
        });
        if (connectedDevices.length == 0) {
          return this.awaitConnectedDevice();
        } else {
          this.dispatch('deviceConnected', connectedDevices);
          return connectedDevices;
        }
      });
    },

    chooseMonitorActiveDevice: function(connectedDevices) {
      // if it's already been set, don't change it without user input
      if (!exists(this.monitor.state.activeDeviceId)) {
        if (connectedDevices.length == 0) {
          throw "No connected devices!";
        }

        return LocalStorage.get(LocalStorage.SPARK_LAST_DEVICE_KEY).bind(this)
        .then(function(lastDeviceId) {
          var lastActiveDevice = _.find(connectedDevices, function(device) {
            return device.id === lastDeviceId;
          });

          if (exists(lastActiveDevice)) {
            this.monitor.setState({activeDeviceId: lastActiveDevice.id});
            return lastActiveDevice;
          } else {
            this.monitor.setState({activeDeviceId: connectedDevices[0].id});
            return connectedDevices[0];
          }
        });
      } else {
        var activeDevice = _.filter(spark.devices, function(device) {
          return device.id == this.monitor.state.activeDeviceId;;
        })[0];
        return Promise.resolve(activeDevice).bind(this);
      }
    },

    getConnectionStatuses: function() {
      console.log("Getting connections statuses");
      return Promise.all(_.map(this.transports, function(transport) {
          return transport.connected();
        }))
      .then(function(statuses) {
        console.log("statuses: " + statuses);
        return _.zip(this.transports, statuses)
      }.bind(this));
    },

    // these checks go in the order of preference for the transports
    chooseActiveConnection: function(connectionStatuses) {
      console.log("choosing active connection");
      console.log(connectionStatuses);

      // from getConnectionStatuses, the form here is
      // [[<firstTransport>, <firstTransport.connected()>], ...]
      var firstConnectedTransportObject = _.find(connectionStatuses, function(status) {
        return status[1];
      });

      if (exists(firstConnectedTransportObject)) {
        console.log(firstConnectedTransportObject[0].transportName, " works!")
        this.activeConnection = firstConnectedTransportObject[0];
        this.monitor.setState({activeConnectionType: firstConnectedTransportObject[0].transportName});
        return Promise.resolve(true);
      } else {
        console.log("No transports work :(");
        return Promise.resolve(false);
      }
    },

    connect: function() {
      if (this.loggedIn()) {
        _.forEach(this.transports, function(transport) {
          var transportDataReceiverId = this.transportDataReceiverIds[transport.transportName];

          // if we're not already getting updates from each transport,
          // register with the ones we're missing
          if (!exists(transportDataReceiverId)) {
            transport.registerDataReceiver({
              pins: this.onNewData.bind(this),
              variables: this.onNewData.bind(this),
              status: this.onNewStatus.bind(this)
            });
          }
          // attempt to connect to all the transports simultaneously
          // they'll phone back when they connect, and we'll use what works
          transport.connect();
        }.bind(this));
      } else {
        throw "Cannot connect to a device when not logged in!";
      }
    },

    resetConnection: function() {
      return Promise.all(_.map(this.transports, function(transport) {
        transport.resetConnection();
      }.bind(this)));
    },

    // if the update rate is insane, slow down - it'll screw up the UI
    onNewData: _.throttle(function(dataObject) {
      // ignore data from inactive connections
      if (this.activeConnection.transportName == dataObject.source) {
        switch (dataObject.feed) {
          case 'pins':
            this.onNewPins(dataObject);
            break;
          case 'variables':
            this.onNewVariables(dataObject);
            break;
        }
      }
    }, 32),

    onNewPins: function(dataObject){
      _.each(this.receivers.pins, function(receiverObject) {
        receiverObject.callback(dataObject);
      }, this);
    },

    onNewVariables: function(dataObject){
      _.each(this.receivers.variables, function(receiverObject) {
        receiverObject.callback(dataObject);
      }, this);
    },

    onNewStatus: function(dataObject) {
      console.log(dataObject);
      switch (dataObject.data) {
        case 'connected':
          this.dispatch('connected', dataObject.source);
          break;
        case 'disconnected':
          this.dispatch('disconnected', dataObject.source);
          break;
      }
    },

    storeToken: function(token) {
      LocalStorage.set(LocalStorage.SPARK_ACCESS_TOKEN_KEY, token);
    },

    /*
      Given an object of the form
      {
        pins: function({
          source: <"LAN"|"API">,
          feed: 'pins'
          data: pinArray
        }),
        variables: function({
          source: <"LAN"|"API">,
          feed: 'variables'
          data: variableObject
        })
      }
      this will result in the appropriate callback being called whenever updates
      are available for either pins or variables.

      Returns an id which can be used to unregister a receiver.

      Receivers will get data via whatever the ConnectionManager deems is the
      best available transport method.
    */
    registerDataReceiver: function(receiverObject) {
      var id = _.uniqueId();

      for (feed in this.receivers) {
        if (receiverObject[feed] !== undefined) {
          this.receivers[feed].push({id: id, callback: receiverObject[feed]});
        }
      }

      return id;
    },

    unregisterDataReceiver: function(receiverId) {
      for (feed in this.receivers) {
        _.remove(this.receivers[feed], function(receiverObject) {
          return receiverObject.id === receiverId;
        });
      }
    },

    loggedIn: function() {
      return spark.ready();
    },

    connected: function() {
      if (!exists(this.activeConnection)) {
        return Promise.resolve(false);
      } else {
        return this.activeConnection.connected();
      }
    }
  }
})();
