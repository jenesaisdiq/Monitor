/** @jsx React.DOM */

var DeviceList = React.createClass({
  mixins: [React.addons.LinkedStateMixin],

  handleChange: function(evt) {
    console.log("Device list switching to:", evt.target.value);
    monitor.setState({activeDeviceId: evt.target.value});
    ConnectionManager.dispatch('changeDevice');
    LocalStorage.set(LocalStorage.SPARK_LAST_DEVICE_KEY, evt.target.value);
  },

  isConnected: function(device) {
    return device.connected;
  },

  getActiveDevice: function() {
    if (exists(this.props.devices) && exists(this.props.activeDeviceId)) {
      return _.filter(this.props.devices(), function(device) {
        return device.id === this.props.activeDeviceId;
      })[0];
    } else {
      return null;
    }
  },

  renderDeviceOption: function(device) {
    var connectedClass = "disconnected";
    if (this.isConnected(device)) {
      connectedClass = "connected";
    }
    return (
      <option value={device.id} key={device.id} className="">{device.name.toUpperCase()}</option>
    );
  },

  renderConnectedDeviceGroup: function() {
    if (this.props.devices != null) {
      var connected = _.filter(this.props.devices, this.isConnected);
      return (
        <optgroup label="CONNECTED">
          {_.map(connected, this.renderDeviceOption)}
        </optgroup>
      )
    } else {
      return '';
    }
  },

  renderDisconnectedDeviceGroup: function() {
    if (this.props.devices != null) {
      var disconnected = _.filter(this.props.devices,
                                  function(d){return !this.isConnected(d)}.bind(this));
      return (
        <optgroup label="DISCONNECTED" disabled >
          {_.map(disconnected, this.renderDeviceOption)}
        </optgroup>
      )
    } else {
      return '';
    }
  },

  maybeRenderNoDevices: function() {
    if (_.filter(this.props.devices, this.isConnected).length == 0) {
      return (
        <option value="NONE" selected disabled style={{display: "none"}}>
          NO DEVICES
        </option>
      );
    }
  },

  render: function() {
    deviceList = this;

    // var noConnectedDevices
    // if (_.filter(this.props.devices, this.isConnected).length == 0)
    if (this.props.devices == null) {
      var selector = (
        <select>
          <option value={null}>LOADING...</option>
        </select>
      );
    } else {
      var selector = (
        <select className='spark-monitor-core-select'
          value={this.props.activeDeviceId}
          onChange={this.handleChange}>
          {this.maybeRenderNoDevices()}
          {this.renderConnectedDeviceGroup()}
          {this.renderDisconnectedDeviceGroup()}
        </select>
      );
    }

    return (
      <div className="spark-monitor-core-select-wrapper">
        {selector}
      </div>
    );
  }

});









