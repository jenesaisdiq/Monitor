/** @jsx React.DOM */

var Login = React.createClass({
  mixins: [React.addons.LinkedStateMixin],
  getInitialState: function() {
    login = this;
    return {
      email: '',
      password: '',
      status: 'unsubmitted'
    }
  },

  handleSubmit: function(e) {
    ConnectionManager.loginWithPassword(this.state.email, this.state.password).then(function(success) {
      if (!success) {
        this.setState({status: 'failed'});
      } else {
        ConnectionManager.connect();
        this.props.parent.forceUpdate();
      }
    }.bind(this));
    e.preventDefault();
  },

  render: function() {
    console.log("login rendering");
    return (
      <div className='spark-monitor-login'>
        <form
          onSubmit={this.handleSubmit}>
          <div className='spark-monitor-input-wrapper'>
            <input
              placeholder="email"
              type="email"
              className='spark-monitor-login-email'
              valueLink={this.linkState('email')} />
            <input
              placeholder="password"
              type="password"
              className='spark-monitor-login-password'
              valueLink={this.linkState('password')} />
          </div>
          <button type='submit'>Monitor</button>
        </form>

        <div
          className={
            'spark-monitor-token-error spark-monitor-login-failure'
            + (this.state.status == 'failed' ? '' : ' invisible')}>
          Unable to log in.
        </div>
        <div
          className={
            'spark-monitor-no-devices spark-monitor-login-failure'
            + (this.state.status == 'no-devices' ? '' : ' invisible')}>
          No devices associated with this account!
        </div>
      </div>
    );
  }
});

