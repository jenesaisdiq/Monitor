/** @jsx React.DOM */

var SparkMonitor = React.createClass({
  mixins: [React.addons.LinkedStateMixin],
  getInitialState: function() {
    return {
      devices: null,
      activeDeviceId: null,
      status: null,
      activeConnectionType: null,
    };
  },

  componentDidMount: function() {
    monitor = this;
    console.log('about to initialize connection');
    ConnectionManager.initialize(this);
  },

  getSelectedDevice: function() {
    var selectedDevices = _.filter(this.state.devices, function(device) {
      return device.id == this.state.activeDeviceId;
    }, this);
    return selectedDevices[0];
  },

  render: function() {
    var contents;
    var connectionStatus;

    if (exists(this.state.activeConnectionType)) {
      connectionStatus = ''; // cloud icon
      if (this.state.activeConnectionType === 'LAN' ||
          this.state.activeConnectionType === 'NodeLAN') {
        connectionStatus = 'lan'; // wifi icon
      } else if (this.state.activeConnectionType === 'SSE') {
        connectionStatus = 'cloud';
      }
    }

    if (ConnectionManager.loggedIn()) {
      // console.log("ConnectionManager logged in, status not awaiting login");
      if (this.state.status === 'connected') {
        // console.log("ConnectionManager connected");
        contents = (
          <div className='spark-monitor-body'>
            <h1 className='spark-monitor-title'>Spark Monitor</h1>
            <span className={'spark-monitor-connection-type spark-connected-' + connectionStatus}></span>
            <DeviceList
              devices={this.state.devices}
              activeDeviceId={this.state.activeDeviceId} />
            <div className='spark-monitor-contents'>
              <PinMonitorList />
              <VariableMonitorList />
            </div>
          </div>
        );
      // selected device is nonexistent or not connected
      } else if ( this.state.status === 'awaitDevices' &&
                  exists(this.state.devices) ) {
        // console.log("Loaded devices, waiting for a connected one");
        if (exists(this.state.activeDeviceId)) {
          contents = (
            <div className='spark-monitor-body'>
              <h1 className='spark-monitor-title'>Spark Monitor</h1>
              <DeviceList
                devices={this.state.devices}
                activeDeviceId={this.state.activeDeviceId} />
              <div className='spark-monitor-contents'>
                <span>Device not connected</span>
              </div>
            </div>
          );
        } else {
          contents = (
            <div className='spark-monitor-body'>
              <h1 className='spark-monitor-title'>Spark Monitor</h1>
              <DeviceList
                devices={this.state.devices}
                activeDeviceId={this.state.activeDeviceId} />
              <div className='spark-monitor-contents'>
                <span>Waiting for connected devices...</span>
              </div>
            </div>
          );
        }
      } else if (this.state.status === 'deviceConnected') {
        // console.log("deviceConnected");
        contents = (
          <div className='spark-monitor-body'>
            <h1 className='spark-monitor-title'>Spark Monitor</h1>
            <DeviceList
              devices={this.state.devices}
              activeDeviceId={this.state.activeDeviceId} />
            <div className='spark-monitor-contents'>
              <span>Connecting to device...</span>
            </div>
          </div>
        );
      } else if (this.state.status === 'disconnected') {
        // console.log("last trigger: disconnected");
        contents = (
          <div className='spark-monitor-body'>
            <h1 className='spark-monitor-title'>Spark Monitor</h1>
            <DeviceList
              devices={this.state.devices}
              activeDeviceId={this.state.activeDeviceId} />
            <div className='spark-monitor-contents'>
              <span>Attempting to reconnect...</span>
            </div>
          </div>
        );
      } else {
        // console.log("loading devices");
        contents = (
          <div className='spark-monitor-body'>
            <h1 className='spark-monitor-title'>Spark Monitor</h1>
            <DeviceList
              devices={this.state.devices}
              activeDeviceId={this.state.activeDeviceId} />
            <div className='spark-monitor-contents'>
              <span>Loading your devices...</span>
            </div>
          </div>
        );
      }

    // not logged in
    } else {
      contents = (
        <div className='spark-monitor-body'>
          <h1 className='spark-monitor-title'>Spark Monitor</h1>
          <div className='spark-monitor-contents'>
            <Login parent={this}/>
          </div>
        </div>
      );
    }
    return contents;
  }

});
// debugger;

window.addEventListener('load', function() {
  React.renderComponent(<SparkMonitor />, document.getElementById("monitor-container"));
}, false);







