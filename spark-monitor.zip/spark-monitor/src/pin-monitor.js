/** @jsx React.DOM */

var PinMonitor = React.createClass({
  history: [],

  render: function() {
    return (
      <div className='pin-graph-container'>
        <h2 id={this.props.pinName + '-label'} className='pin-label'>{this.props.pinName}</h2>
        <div
          id={this.props.pinName + '-graph'}
          className='pin-graph epoch epoch-theme-dark'
          style={{
            width: '60px',
            height: '20px'
          }} >
        </div>
        <span id={this.props.pinName + '-value'} className='pin-value'>
          {this.props.readMode == 'analogread' ? '----' : '-'}
        </span>
      </div>
    );
  },

  loadAnalogGraph: function() {
    var time = (new Date).getTime();
    var emptyGraphValues = _.map(_.range(60), function(i) {
      return {x: (time - i * 5), y: 2048};
    });
    // console.log(emptyGraphValues);

    var epoch = $(this.getDOMNode()).find('.pin-graph').epoch({
      type: 'time.line',
      axes: [],
      margins: { top: 0, right: 0, bottom: 0, left: 0 },
      // tickFormats: {bottom: function() {return ''}, y: function() {return ''}},
      data: [{values: emptyGraphValues}],
      range: [0, 4200],
      // windowSize: 20,
      // queueSize: 1,
      // animationSpeed: 4
      // fps: 60
    });
    return epoch;
  },

  loadDigitalGraph: function() {
    var time = _.now() / 1000;
    var emptyGraphValues = _.map(_.range(60), function(i) {
      return {time: (time - i), y: 0.5};
    });

    var epoch = $(this.getDOMNode()).find('.pin-graph').epoch({
      type: 'time.line',
      axes: [],
      margins: { top: 0, right: 0, bottom: 0, left: 0 },
      tickFormats: {x: function() {return ''}, y: function() {return ''}},
      data: [{values: emptyGraphValues}],
      range: [0, 1],
      // windowSize: 20,
      // queueSize: 1,
      // animationSpeed: 60
      // fps: 60
    });
    return epoch;
  },

  loadGraph: function() {
    this.epoch = null;
    if (this.props.readMode == 'analogread') {
      this.epoch = this.loadAnalogGraph();
    } else if (this.props.readMode == 'digitalread') {
      this.epoch = this.loadDigitalGraph();
    }
  },

  componentWillReceiveProps: function(nextProps) {
    this.epoch.data[0].values.push({x: _.now(), y: nextProps.pinValue});
    this.epoch.data[0].values = this.epoch.data[0].values.slice(-60); // limit # items in the graph
    this.epoch.update(this.epoch.data);
    this.epoch.options.domain = [
      this.epoch.data[0].values[0].x,
      this.epoch.data[0].values[this.epoch.data[0].values.length - 1].x
    ]
    // this.epoch.data = {values: this.history};
    // console.log(this.history);
    // this.epoch.push([{time: _.now(), y: nextProps.pinValue}]);

    var value_text = nextProps.pinValue;
    if (this.props.readMode == 'analogread') {
      value_text = fourDigitify(nextProps.pinValue);
    }
    $('#' + this.props.pinName + '-value').text(value_text);
  },

  shouldComponentUpdate: function(nextProps, nextState) {
    return false;
  },

  componentDidMount: function() {
    this.loadGraph();
  },
});

var PinMonitorList = React.createClass({
  ANALOG_PIN_NAMES: ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7"],
  DIGITAL_PIN_NAMES: ["D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7"],

  getInitialState: function() {
    return {
      analogPinValues: _.times(8, function() {return 2048;}),
      digitalPinValues: _.times(8, function() {return 0.5;}),
    };
  },

  render: function() {
    var renderPinGraph = function(readMode, pin) {
      var pinName = pin[0];
      var pinValue = pin[1];
      return (<PinMonitor key={pinName} readMode={readMode} pinName={pinName} pinValue={pinValue}/>)
    };
    return (
      <div className='pin-graphs'>
        <span className='graphs-column'>
          <h2 className='graphs-header'>analog</h2>
          {_.map(
            _.zip(this.ANALOG_PIN_NAMES, this.state.analogPinValues),
            renderPinGraph.bind(this, 'analogread')
          )}
        </span>
        <span className='graphs-column'>
          <h2 className='graphs-header'>digital</h2>
          {_.map(
            _.zip(this.DIGITAL_PIN_NAMES, this.state.digitalPinValues),
            renderPinGraph.bind(this, 'digitalread')
          )}
        </span>
      </div>
    );
  },

  onNewPins: function(pinsObject) {
    var newPins = pinsObject.data;
    this.setState({
      analogPinValues: newPins.slice(0,8),
      digitalPinValues: newPins.slice(8)
    });
  },

  componentDidMount: function() {
    this.receiverId = ConnectionManager.registerDataReceiver({
      pins: this.onNewPins
    });
  },

  componentWillUnmount: function() {
    ConnectionManager.unregisterDataReceiver(this.receiverId);
  },


});













