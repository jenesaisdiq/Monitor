var LocalStorage = (function() {
  return {
    SPARK_ACCESS_TOKEN_KEY: 'spark_access_token',
    SPARK_LAST_DEVICE_KEY: 'spark_last_device_id',

    get: function(id) {
      if (chromeAvailable()) {
        return new Promise(function(resolve, reject) {
          chrome.storage.local.get(function(data) {
            resolve(data[id]);
          });
        });
      } else {
        var value = window.localStorage[id];
        value = value === "undefined" ? undefined : value;
        return Promise.resolve(value);
      }
    },

    set: function(id, data) {
      if (chromeAvailable()) {
        return new Promise(function(resolve, reject) {
          var dataObject = {};
          dataObject[id] = data;
          chrome.storage.local.set(dataObject, function() {
            resolve();
          });
        });
      } else {
        window.localStorage[id] = data;
        return Promise.resolve(true);
      }
    }
  }
})();
