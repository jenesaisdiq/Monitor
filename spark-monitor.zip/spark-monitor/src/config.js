API_BASE = function() {
  return "https://api.spark.io/v1/devices/" + DEVICE_ID + "/";
};

BASE_SAMPLE_RATE = 200; // base rate of ms between samples
MIN_SAMPLE_RATE = 200;