//TODO: this is only for development
Promise.longStackTraces();

var fourDigitify = function(n) {
  if (n<=9999) {
    n = ("000"+n).slice(-4);
  }
  return n;
};

var exists = function(obj) {
  if (typeof obj === 'undefined') {
    return false;
  } else {
    return obj != null && obj != undefined;
  }
}

var guid = function() {
  'xxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
    return v.toString(16);
  });
}

var ab2str = function(buf) {
  return String.fromCharCode.apply(null, new Uint8Array(buf));
}

var requireAvailable = function() {
  if (typeof require === 'undefined') {
    return false;
  } else {
    return exists(require);
  }
}

var chromeAvailable = function() {
  if (typeof chrome === 'undefined') {
    return false;
  } else {
    return exists(chrome);
  }
}
