/** @jsx React.DOM */

var VariableMonitor = React.createClass({
  getInitialState: function() {
    return {enabled: true, value: '----'};
  },

  render: function() {
    return (
      <tr className='spark-monitor-variable'>
        <td className='spark-monitor-variable-label-cell'>
          <h2 id={this.props.variable + '-label'}
              className='variable-label'>{this.props.variableName}</h2>
        </td>
        <td className='spark-monitor-variable-value-cell'>
          <p id={this.props.variable + '-value'}
             className='variable-value'>{this.props.variableValue}</p>
        </td>
      </tr>
    );
  }

});

var VariableMonitorList = React.createClass({
  getInitialState: function() {
    return {variables: {}};
  },

  render: function() {
    var renderVariableMonitor = function(variableValue, variableName) {
      return (
        <VariableMonitor variableName={variableName} variableValue={variableValue} />
      )
    };

    return (
      <div className='spark-monitor-variable-list'>
        <h2 className='spark-monitor-variables-header'>variables</h2>
        <table className='spark-monitor-variable-table'>
          <tbody>
            {_.map(this.state.variables, renderVariableMonitor)}
          </tbody>
        </table>
      </div>
    )
  },

  onNewVariables: function(dataObject) {
    this.setState({variables: dataObject.data});
  },

  componentDidMount: function() {
    this.receiverId = ConnectionManager.registerDataReceiver({
      variables: this.onNewVariables
    });
  },

  componentWillUnmount: function() {
    ConnectionManager.unregisterDataReceiver(this.receiverId);
  },




















});
