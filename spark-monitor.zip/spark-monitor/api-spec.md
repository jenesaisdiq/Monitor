# API spec

In all cases, `<thing>` should be replaced with "the value of of 'thing'".

## Publish

 name   |  data
------  | ------
`pins`  | `<analog1>,<analog2>,...,<digital1>,<digital2>,...`
`vars`  | `<var1name>:<var1value>,<var2name>:<var2value>,...`


## LAN

### Pins   

There's a `~` at the end of each of these because sometimes on LAN multiple packets get jammed together. The `~` is to make it easy to split them back apart.

Whitespace doesn't matter.

```
{   
    "type": "pins",
    "pins": {
        "analog": [<analog1>,<analog2>,...,<digital1>,<digital2>,...],
        "digital": [<analog1>,<analog2>,...,<digital1>,<digital2>,...]
    }
}~
```

### Vars
```
{   
    "type": "vars",
    "vars": {
        "<var1name>": "<var1value>",
        "<var2name>": "<var2value>"
    }
}~
```
