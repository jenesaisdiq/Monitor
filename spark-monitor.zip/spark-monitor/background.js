chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('index.html', {
    id: 'spark-monitor-id',
    innerBounds: {
      width: 400,
      height: 800,
      minWidth: 400,
      maxWidth: 400
    }

  });
});