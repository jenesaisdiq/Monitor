# Spark Monitor

This project contains the code for the Spark Monitor (to be renamed) client which, in combination with the Spark Monitor [firmware library](https://github.com/willwhitney/spark-monitor-firmware), can show in real time the voltages at the pins and the values of variables on a Spark Core.

It runs as a Chrome app; in a Node environment, such as Atom or Spark Dev; and as a packaged Chrome app on Android and iOS.

<img src="http://i.imgur.com/aIUIqN4.png" height=300>
<img src="http://i.imgur.com/iodVvES.png" height=300>
<img src="http://i.imgur.com/n9vQibo.png" height=300>

## Development

### Structure

There are three projects as part of this product. This one, `spark-monitor`, contains all the guts and logic for the client. [`spark-monitor-atom`](https://github.com/willwhitney/spark-monitor-atom) contains a wrapper for Atom environments such as Spark Dev. [`spark-monitor-firmware`](https://github.com/willwhitney/spark-monitor-firmware) contains the firmware library that talks to this client.

### Dev Dependencies

1. JSX/React: `npm install -g react-tools`
2. Sass: `gem install sass`
3. grunt: `npm install -g grunt-cli`

#### Mobile Dev Dependencies

The mobile versions are based on the [Chrome mobile apps](https://developer.chrome.com/apps/chrome_apps_on_mobile) project.

1. Depending on whether you're building for Android or iOS, you will need the [appropriate SDKs](https://developer.chrome.com/apps/chrome_apps_on_mobile#development-dependencies-for-all-platforms) for your target platform(s).

2. [Chrome mobile apps](https://developer.chrome.com/apps/chrome_apps_on_mobile) tools: `npm install -g cca`


### Building

There are two components to building the core project.

1. `jsx --watch src/ build/`
2. `sass --watch style/*.scss`

#### Building for Atom/Spark Dev

1. Clone this project and the [Spark Monitor Atom](https://github.com/willwhitney/spark-monitor-atom) project into the same enclosing directory. Leave them named as they are.
2. `grunt watch` in this directory, and it will compile the JS `build/` directory and the CSS `style/` directory into one complete file for each, then copy those files into the `spark-monitor-atom` project.

Directory structure:

```
enclosing-directory/
|-- spark-monitor/
|   |-- build/
|   |-- style/
|   |-- <this readme>
|-- spark-monitor-atom/
|-- ...
|-- <whatever else is in this dir is fine>
```

#### Building for Mobile

Use the `cca` tool to generate a project directory: `cca create spark-monitor-mobile --link-to=<path-to-enclosing-dir>/spark-monitor/manifest.json`

This creates symlinks to the main `spark-monitor` project (this one), so any changes you make here will be reflected next time you run the mobile app using the `cca` tool.


## Installing

### Chrome

1. Go to [chrome://extensions](chrome://extensions/)
2. Click the "Developer mode" check box in the upper right
3. Click "Load unpacked extension..."
4. Select this directory (`spark-monitor`)
5. Celebrate a hard day's work. The app opens just like any other Chrome packaged app.

After you've made changes to the project and JSX/Sass compile, you can right click on the running Spark Monitor and hit "Reload" to pull in the changes.


### Atom/Spark Dev

1. Figure out where your packages get installed. For me, that's `/Users/will/.atom/packages` and `/Users/will/.sparkdev/packages` for Atom and Spark Dev, respectively.
2. Create a symlink from your `spark-monitor-atom` folder into this packages directory: `ln -s /Users/will/code/spark-monitor-atom /Users/will/.sparkdev/packages/spark-monitor-atom`
3. You may need to reload Atom.
4. ⌘-⇧-P to open the command pane, then look for `Spark Monitor: Toggle`

Whenever you make changes and JSX/Sass compile, Grunt will copy everything over into the Atom project. If you've got that project installed in Atom as described below, you can hit ⌘-⌥-⌃-L (or search in the command palette for "reload") to reload your Atom packages.

### Mobile

The iOS part of this is untested (I have neither a device nor an Apple developer license), but should theoretically work. There are going to be some steps about setting up your device, I imagine.


0. Set up your Android device to allow development:
    > Enable USB debugging on your device.

    > On Android 4.2 and newer, Developer options is hidden by default. To make it available, go to Settings > About phone and tap Build number seven times. Return to the previous screen to find Developer options.

1. `cd` into the `spark-monitor-mobile` directory that you created with `cca`
2. `cca run <android | ios>`
3. It will do a bunch of setup, then install and run the app on your device.

More documentation, including things like running on simulated devices, is available from the [Chrome mobile apps](https://developer.chrome.com/apps/chrome_apps_on_mobile) project.


## Use

Check out the [sweet sample code](https://github.com/willwhitney/spark-monitor-firmware/blob/master/testCode.ino) in the [Spark Monitor Firmware](https://github.com/willwhitney/spark-monitor-firmware) repo for how to use the library. Once you've got some firmware on your core that uses the Monitor library, open up one of the Monitor apps and select your device.

If you want to build additional transport mechanisms or things like that, check out the `api-spec.md` in this directory.


## Technical details

### Connectivity

This project implements three different transport modules and smoothly transitions between them depending on what transports work at any given time. It preferentially uses transports in a given order, first LAN, then SSE, to give the fastest updates possible given the current network environment.

The simplest of these is the SSEConnection `src/connection-sse-connection.js`. It subscribes to the `Spark.publish` stream from the core and processes incoming messages that have information about the current status of the pins and watched variables.

More complicated is the LAN transport. This transport method opens a direct TCP connection on the local network between the Core (acting as a server) and this client. In order to find the IP address to connect to, this transport relies on the firmware setting a variable called `ip` with `Spark.variable` to announce its IP address. This client then opens a TCP socket to that IP.

Depending on the environment, there are two different LAN transports: LANConnection and NodeLANConnection. LANConnection uses the Chrome sockets API and works in Chrome and (as a Chrome packaged app) on mobile. NodeLANConnection uses the Node `net.sockets` API and works in Atom (or, I imagine, any other Node-based frontend environment).

All three of these transports have the same API for checking their status and registering new receivers of their data.

As you might expect, juggling the states of these connections as the device starts/stops/reconnects/gets flashed/crashes as the Monitor starts up/logs in/finds devices/loses devices/experiences network partitions/etc can get pretty hairy. Making this work well, with a simple, pluggable API for new transport methods in the future, was the bulk of this work.

The connections are orchestrated by the ConnectionManager. The ConnectionManager receives triggers about the state of the Monitor and its connections and dispatches them to the appropriate parties. This includes sending updates to the UI and forcing refreshes. It implements the same API for subscribing to data and checking status that each of the transports does; its responses are an abstraction over those of all the transports.

The Monitor firmware currently supports any number of connected clients; however, only one will be able to connect via LAN for high-speed updates.


## Cool swag

If you've got a phone that supports USB Host, then with a USB OTG cable, you can power a Core. If you can make a WiFi hotspot from your phone, a Core can use that as its internet connection. If you put that together with the Monitor, you've got a pretty sweet mobile development rig.

[Youtube video](https://www.youtube.com/watch?v=Cp7dNjKOOV8)
