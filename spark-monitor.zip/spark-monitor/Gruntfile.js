module.exports = function(grunt) {

  grunt.initConfig({
    // pkg: grunt.file.readJSON('package.json'),
    concat: {
      options: {
        banner: "exports = undefined; module.exports = undefined;",
        footer: "module.exports = {React: React,SparkMonitor: SparkMonitor}\n",
        separator: ';'
      },
      dist: {
        src: [
          "lib/react-with-addons.js",
          "lib/jquery-1.11.0.min.js",
          "lib/d3.min.js",
          "lib/epoch.js",
          "lib/lodash.js",
          "lib/spark.min.js",
          "lib/bluebird.js",
          "build/util.js",
          "build/config.js",
          "build/local-storage.js",
          "build/connection/api-rate-limiter.js",
          "build/connection/api-connection.js",
          "build/connection/sse-connection.js",
          "build/connection/lan-connection.js",
          "build/connection/node-lan-connection.js",
          "build/connection/connection-manager.js",
          "build/device-list.js",
          "build/login.js",
          "build/pin-monitor.js",
          "build/variable-monitor.js",
          "build/monitor.js"
        ],
        dest: 'combine.js'
      }
    },

    copy: {
      main: {
        files: [
          // includes files within path
          {flatten: true, src: ['combine.js'], dest: '../spark-monitor-atom/lib/', filter: 'isFile'},
          {flatten: true, src: ['style/style.css'], dest: '../spark-monitor-atom/styles/combine.css'},
        ],
      },
    },

    watch: {
      scripts: {
        files: ['build/*.js', 'build/*/*.js'],
        tasks: ['concat', 'copy'],
        options: {
          spawn: false,
        },
      },
    },

    //,
    // concat_js: {
    //   options: {
    //     separator: ';'
    //   },
    //   dist: {
    //     src: ['build/**/*.js'],
    //     dest: 'dist/<%= pkg.name %>.js'
    //   }
    // },
    // watch: {
    //   files: ['<%= jshint.files %>'],
    //   tasks: ['jshint', 'qunit']
    // }
  });

  // grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-watch');

  grunt.registerTask('build', ['concat']);

};